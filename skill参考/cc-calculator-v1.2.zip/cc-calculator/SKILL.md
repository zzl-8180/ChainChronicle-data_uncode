---
name: cc-calculator
description: Calculate Chain Chronicle (锁链战记/チェンクロ) Chain, skill buffs, damage, criticals, pursuit, and DPS. Use when the user asks to calculate or compare buff order, Chain/チェイン, Mana Chain Buff, Button Buff, 必杀威力UP, 乘算/加算/共鸣/别框加算, normal attack, critical, pursuit, skill damage, DPS, or provides a Chain Chronicle character/database URL and asks for a damage calculation.
---

# Chain Chronicle Calculation Skill

用于《锁链战记 / Chain Chronicle / チェインクロニクル》的伤害、Buff、Chain 与 DPS 计算。

本 skill 的目标不是“只给一个结果”，而是把**数据来源、乘区分类、触发条件、公式和假设**说明白，使结果可以复算。

## 必读参考

开始计算前按任务需要读取：

- `references/chain-rules.md`：Chain、Mana Chain Buff、Button Buff、万象 Mana、必杀威力 UP。
- `references/damage-rules.md`：攻击 Buff 乘区、普通攻击、暴击、追击、必杀、DPS、取整。
- `references/bond-weapon-rules.md`：羁绊基础 ATK / 羁绊能力 / 武器攻击格 / 暴击格 / 武器能力。
- `references/term-map.md`：与计算有关的日中术语和文本识别规则。
- `references/evidence.md`：资料来源、证据等级、尚未完全确认的边角机制。
- `references/regression-tests.md`：已知案例和预期结果。修改规则后用它检查是否破坏旧结果。

如需大量排列或精确数值，可运行 `scripts/cc_calc.py`。脚本只实现已经固化的核心规则；角色级例外仍以参考文件和用户提供的实测为准。

## 与 cc-translator 的职责边界

`cc-translator` 负责把日文游戏文本翻译成数据库风格中文；本 skill 负责把技能/觉醒/Extra/Leader 等文本**分类成计算字段并进行计算**。

如果用户同时给出日文原文和数值：

1. 优先使用已经确认的数据库中文/用户提供翻译。
2. 若需要翻译且 `cc-translator` 可用，按其术语体系处理。
3. 本 skill 不因为“看起来像某个 Buff”就擅自补未知数值或乘区。

## 总体工作流

1. 收集角色与战斗状态数据；有羁绊/武器时单独核对基础 ATK、攻击格与装备能力效果。
2. 区分“原始技能数值”和“被 Chain/必杀威力强化后的实际数值”。
3. 先算当前必杀的 Chain 状态，再算技能效果。
4. 将强化后的 Buff 数值放回其原来的乘区：乘算 / 加算 / 共鸣 / 别框加算。
5. 计算基础伤害、普通攻击、暴击、追击或必杀伤害。
6. 若计算 DPS，再除以实际攻击间隔。
7. 输出时明确区分：
   - `Buff量`：例如 +60%。
   - `总倍率`：例如 ×1.60。
   - `相对提升`：例如方案甲比方案乙高 5.2%。
8. 对未知机制必须标记“待确认”，不得静默猜测。

## 数据获取优先级

用户提供具体角色时按以下顺序：

1. 用户直接给出的数值、截图、实测。
2. 用户指定的数据库页，例如 `http://att.koncoo.com/cc/db/Detail.aspx?id=...`。
3. 当前可靠攻略/日文资料。
4. 文本模式推断，只能作为临时分类，并标注“推定”。

数据库无法访问时，不要编造字段；让用户贴文本/截图，或用其他可访问资料交叉确认。

## Chain 计算核心

### 1. 默认 Chain

当前技能在同一条 Chain 内的序号用 `n` 表示：第一发 `n=0`，第二发 `n=1`。

默认 Chain 加成为：

```text
n=0: 0%
n=1: 10%
n=2: 20%
n=3: 30%
n>=4: 50%  (MAX Chain)
```

因此第六名不同角色继续同一 Chain 时仍为 MAX，不变成 60%。

### 2. Mana Chain Buff 与 Button Buff 必须分开

内部至少使用以下字段：

```text
mana_chain_bonus
button_chain_bonus
mana_chain_scaled_bonus
button_chain_scaled_bonus
instant_chain_bonus
```

- **Mana Chain Buff**：上一发实际“消耗 Mana/法珠”才触发，作用于同 Chain 的下一发。
- **Button Buff**：上一发通过必杀按钮发动才触发，作用于同 Chain 的下一发。
- 二者可以同时触发，数值与默认 Chain **加算**。
- 0 Mana 必杀默认不触发 Mana 型，但只要是按钮发动仍可触发 Button 型。
- 第一发不会凭空得到“下一发”型 Chain Buff；除非题目明确说在第一发之前已经有待结算的同 Chain 效果。

### Extra 的突破档位解析（重要）

数据库中 `（32/34/36/38/40%）` 属于**同一卡 0破/1破/2破/3破/4破的五个互斥档位**，绝对不是五个同时叠加的数值；也不是 `1st/2nd/3rd/MAXChain` 的随 Chain 档位变化加成。

```text
突破0 -> +32%
突破1 -> +34%
突破2 -> +36%
突破3 -> +38%
突破4 -> +40%
```

每一个实例只贡献它当前突破档位的一个 Button Buff。若文字写“此效果在后备队伍时也能发动”，则位于后备仍可作为 **下一发 Chain 加成来源**；后备的普通前场光环、本人按键必杀和直接 DPS 不能因此自动生效。统计合计加成时逐个角色核对是否在前场/后备可发动。

示例：其他 6 人均为 0 破（各 +32%），候选第 5 前场角色 4 破（+40%），且七份都能触发：

```text
button_chain_total = 6×32% + 40% = 232%
MAXChain multiplier = 1 + 50% + 232% = 3.82
```

候选卡若额外具有 `2.5/5/7.5/10%` 的**随 Chain 档位成长**效果，必须再按位置单独加算，不可把它与 Extra 突破档位混为一项。

### 3. 当前必杀的 Chain 倍率

```text
chain_bonus_total = default_chain_bonus
                  + pending_mana_chain_bonus
                  + pending_button_chain_bonus
                  + pending_scaled_chain_bonus
                  + instant_chain_bonus

chain_multiplier = 1 + chain_bonus_total
```

例：1stChain，固定 Mana+Button 合计 240%，无其他项：

```text
1 + 10% + 240% = 3.50
```

若该发使用万象 Mana，并且万象 Mana 的即时修正为 +10%：

```text
1 + 10% + 240% + 10% = 3.60
```

### 4. 随 Chain 档位变化的“下一发”加成

例如文本表示下一发按 `1st/2nd/3rd/MAX = 2.5/5/7.5/10%` 增加，则它是单独的 scaled 项，按**受益的下一发当前 Chain 档位**取值，再与其他 Chain 项加算。

不要把它误写成固定 +10%。

## 必杀威力 UP

必杀威力 UP 不属于 Chain 区。

多个必杀威力 UP（无论来自 LA、LS、觉醒或其他角色，只要同时作用于这次必杀）彼此**乘算**；**不是**简单相加。这与各类攻击 Buff 原本属于加算池还是乘算池是不同的问题：

```text
skill_power_multiplier = Π(1 + s_i)
```

例如 15% 与 5%：

```text
1.15 × 1.05 = 1.2075
```

有些必杀威力 UP 只强化伤害、不强化 Buff；有些特殊类型能影响自动技能。必须按效果组件保存是否适用，不能只存一个全局百分比。

## 必杀 Buff 被强化的顺序

对于一个可被 Chain/必杀威力强化的原始 Buff 数值 `b_raw`：

```text
b_actual = b_raw × chain_multiplier × skill_power_multiplier
```

然后再把 `b_actual` 放回它本来的 Buff 类别。

**Chain 只改变 Buff 数值，不改变 Buff 的乘区。**

例如一个原始 +60% 的“乘算型攻击 Buff”，强化后变成 +210%，最终贡献 `×3.10`；如果原本属于“加算型”，则 +210% 进入加算池并受该池上限约束。

### 条件技能先选原始版本

如果技能写：

```text
0Chain: 攻击 +60%
1stChain以上: 攻击 +65%
```

应先根据当前 Chain 选出 `65%`，再做 Chain/必杀威力强化：

```text
65% × chain_multiplier × skill_power_multiplier
```

不要把“多出来的 5%”当成一个独立乘区。

### 默认可/不可强化范围

按当前已确认资料：

- 可强化：多数按钮必杀中的攻击 Buff、防御 Buff。
- 不可强化：明确标“固定”的效果、暴击威力 Buff、追击倍率；自动技能附带 Buff 原则上也不强化。
- Debuff 默认不强化；“无伤害领域型 Debuff”存在确认例外。
- 必须按**技能效果组件**记录 `chain_scalable` 与 `skill_power_scalable`，不能按整个技能一刀切。

## 攻击 Buff 乘区

### 乘算 Buff

```text
M = Π(1 + m_i)
```

通常没有 100% 总上限。

### 普通加算 Buff

```text
A = min(Σ a_i, 100%)
```

### 共鸣 Buff

```text
R = min(Σ r_i, 100%)
```

普通加算和共鸣是两个独立池，各自上限 100%，在攻击基础倍率中组合为：

```text
1 + A + R
```

### 别框加算 Buff

同一来源/同一 stack key 内部先加算并应用该来源上限；不同来源之间乘算：

```text
E = Π_j (1 + e_j)
```

其中 `e_j` 是第 j 个独立来源已经叠好的实际值。

不同角色提供的同类“别框加算”也按不同来源处理，除非有明确资料说明共享 stack key。

## 羁绊与武器（必须读 bond-weapon-rules.md）

- 羁绊基本属性加成属于角色**面板 ATK**，优先用编队中已经包含羁绊/亲爱度的 ATK；不能再次叠加。
- 武器攻击格不是面板 ATK 百分比：通常 `每格 +100`、`+ 每格 +130`、`++ 每格 +170` 固定伤害，在通用攻击乘区之后加上。武器暴击格影响**暴击率**，不是暴击倍率。
- 羁绊能力、武器能力的来源标签 `bond` / `weapon_ability` 不产生新乘区。必须依能力内容区分：全队乘算光环、个人攻击乘算、暴击威力数值加算、必杀威力乘算、Mana/Button 下一发 Chain 加算、条件别框等。
- 羁绊和武器能力可能改变全队输出，不能只在计算装备者 DPS 时读取；但**只有**文字指定为全队且条件满足时才传播给队友。
- 暴击概率与暴击威力是不同属性；若用户设全暴击，不要把武器暴击格当成 +暴伤。

## 基本伤害

常规武器：

```text
base_stat_damage = floor(ATK / 10)
```

攻击 Buff 后的“基本伤害”定义为：

```text
basic_damage = base_stat_damage
             × M
             × (1 + A + R)
             × E
```

拳/双剑等存在基础伤害特殊规则，见 `references/damage-rules.md`；没有确认武器类别时不要擅自套特殊公式。

## 普通攻击、暴击、追击

### 普通攻击

```text
normal_hit = floor((basic_damage + weapon_bonus + chronicle_bonus) × debuff_multiplier)
```

### 暴击倍率

暴击威力的各类 Buff 在这里有特殊规则：它们最终都作为“加到暴击倍率上的数值”处理，而不是像攻击力乘算 Buff 那样彼此相乘。

```text
crit_multiplier = 1.5
                + crit_multiplicative_value
                + crit_additive_value_capped
                + crit_resonance_value_capped
                + crit_separate_additive_values_capped
```

具体分池与上限见 `references/damage-rules.md`。

单段暴击：

```text
crit_hit = floor((basic_damage × crit_multiplier + weapon_bonus + chronicle_bonus)
                 × debuff_multiplier)
```

### 追击

单次追击：

```text
pursuit_hit = ceil(basic_damage × pursuit_multiplier)
```

追击默认不吃 Chain 对“追击倍率”的强化。

对于已确认“每个暴击 Hit 都触发追击”的普通攻击结构：

```text
cycle_damage = crit_hit_count × (crit_hit + Σ pursuit_hits_per_crit_hit)
```

不要把“一轮攻击只追击一次”作为全局默认。角色级机制不同则用 override。

## 必杀伤害

按钮发动的必杀：

```text
skill_damage = floor(
    (basic_damage
     × skill_damage_multiplier
     × chain_multiplier
     × skill_power_multiplier
     + weapon_bonus)
    × debuff_multiplier
)
```

自动技能原则上：

```text
auto_skill_damage = floor(
    (basic_damage × skill_damage_multiplier + weapon_bonus)
    × debuff_multiplier
)
```

默认不吃 Chain 与必杀威力 UP，但存在已确认例外：

1. 共鸣自动技能若由**该角色自己的当前必杀**满足触发条件，可继承该发 Chain。
2. 某些“不强化 Buff”的必杀威力 UP 可作用于自动技能伤害。

遇到这些情况必须按角色文本/实测建模。

## Debuff

普通伤害 Debuff：

```text
debuff_total = min(Σ d_i, 100%)
debuff_multiplier = 1 + debuff_total
```

不要把敌人防御降低与我方攻击 Buff 混到同一池。

## DPS

严格定义：

```text
DPS = damage_per_attack_cycle / actual_attack_interval_seconds
```

输出时优先同时给：

```text
damage_per_attack_cycle
attack_interval
dps
```

避免把“一轮完整暴击伤害”误叫成 DPS。

## Buff 覆盖与来源

- 同一个 actor 重复施放自己的同一技能 Buff，默认后一次覆盖前一次。
- 自有角色与好友同名角色是不同 actor，可作为独立来源共存。
- 已知存在少量例外；没有资料时保留 `stack_override`，不得擅自叠加。

推荐内部键：

```text
source_actor_id
ability_id
stack_key
buff_category
```

## Chain 状态机建议

每次技能事件至少记录：

```text
actor_id
uses_skill_button: true/false
mana_consumed: numeric or boolean
uses_universal_mana: true/false
chain_breaks: true/false
```

处理顺序：

1. 根据当前同 Chain 的不同 actor 数决定 `n` 与默认 Chain。
2. 读取上一发已经触发、待作用于本发的 Mana/Button/Scaled bonus。
3. 加本发即时 Chain 修正（如万象 Mana）。
4. 得到 `chain_multiplier`。
5. 选择当前技能的原始条件版本。
6. 强化本发可强化的伤害/Buff/Debuff 组件。
7. 结算本发并更新主动 Buff 状态。
8. 根据本发是否实际消耗 Mana、是否按按钮，生成**下一发**的 pending Chain Buff。
9. 若同 actor 重复、超时或其他条件断 Chain，则清空 Chain 状态和 pending next-chain 效果。

## 排序问题

用户问“Buff 顺序差多少”时：

1. 明确每个位置的有效 `chain_multiplier`。
2. 对每个角色计算其实际 Buff。
3. 按正确乘区合并；若题目明确说“这些 Buff 互为独立乘算”，直接乘。
4. 给出至少：
   - 最优顺序及总倍率
   - 最差顺序及总倍率
   - `最优 / 最差 - 1` 的相对提升
   - `1 - 最差 / 最优` 的从最优掉到最差的损失
5. 若只比较两个顺序，直接比较两者，不必枚举全部。

对于“独立乘算的攻击 Buff，且所有后续技能都能稳定触发相同 next-chain 加成”的简化题，数值较大的 Buff 通常应放更高 Chain；但不要把这个经验规则替代实际枚举，尤其当 Mana/Button 触发条件或技能本体分支不同。

## 输出要求

默认用中文，公式清楚但不堆砌无关术语。

推荐结构：

1. **输入与假设**：列出角色数值、Chain 类型、Mana/Button 条件。
2. **位置倍率**：列出每一发的 Chain multiplier。
3. **逐项计算**：每个角色的 raw buff → actual buff → final factor。
4. **总结果**。
5. **比较**：相对差距与实战意义。
6. **未确认项**：如果存在，单独说明其可能影响。

绝对不要把：

```text
Buff +60%
```

和：

```text
总倍率 ×1.60
```

混写成同一个“60%倍率”。

## 证据与不确定性

规则分为：

- `CONFIRMED`：攻略公式/多来源实测一致，可直接计算。
- `SUPPORTED`：有可靠单一实测或当前数据库证据，通常可用。
- `PROVISIONAL`：逻辑推断但缺直接实测，必须在答案中说明。
- `UNKNOWN`：不计算，要求补资料或做区间/情景分析。

当前主要未决项见 `references/evidence.md`。中间步骤取整时机尚未完全调查清楚；除已确认的 floor/ceil 节点外，不要自行插入额外取整。
