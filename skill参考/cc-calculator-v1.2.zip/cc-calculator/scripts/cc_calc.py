#!/usr/bin/env python3
"""Small deterministic helpers for the cc-calculator skill.

This is not a full battle simulator. It implements the stable core formulas used
by the skill and a permutation helper for independent skill buffs.
"""
from __future__ import annotations

import argparse
import itertools
import math
from dataclasses import dataclass
from functools import reduce
from operator import mul
from typing import Iterable, Mapping, Sequence


def product(xs: Iterable[float]) -> float:
    return reduce(mul, xs, 1.0)


def default_chain_bonus(chain_index: int) -> float:
    """0-based skill index within an unbroken chain -> bonus as decimal."""
    if chain_index <= 0:
        return 0.0
    if chain_index == 1:
        return 0.10
    if chain_index == 2:
        return 0.20
    if chain_index == 3:
        return 0.30
    return 0.50


def chain_stage(chain_index: int) -> str:
    if chain_index <= 0:
        return "start"
    if chain_index == 1:
        return "1st"
    if chain_index == 2:
        return "2nd"
    if chain_index == 3:
        return "3rd"
    return "max"


def chain_multiplier(
    chain_index: int,
    *,
    pending_mana_bonus: float = 0.0,
    pending_button_bonus: float = 0.0,
    pending_scaled_bonus: float = 0.0,
    instant_bonus: float = 0.0,
) -> float:
    return 1.0 + default_chain_bonus(chain_index) + pending_mana_bonus + pending_button_bonus + pending_scaled_bonus + instant_bonus


def extra_button_bonus_by_breakthrough(breakthrough: int) -> float:
    """Modern 32/34/36/38/40% Extra wording: 0/1/2/3/4 limit-break tiers.

    Returns exactly one value as a fraction; do not sum all tier values.
    """
    values = (0.32, 0.34, 0.36, 0.38, 0.40)
    if isinstance(breakthrough, bool) or not isinstance(breakthrough, int) or not (0 <= breakthrough <= 4):
        raise ValueError("breakthrough must be integer from 0 to 4")
    return values[breakthrough]


def skill_power_multiplier(ups: Sequence[float]) -> float:
    return product(1.0 + x for x in ups)


def amplify_effect(raw: float, chain_mult: float, skill_power_mult: float = 1.0, *, scalable: bool = True) -> float:
    return raw * chain_mult * skill_power_mult if scalable else raw


def independent_buff_total(raw_buffs: Mapping[str, float], order: Sequence[str], position_chain_multipliers: Sequence[float]) -> float:
    if len(order) != len(position_chain_multipliers):
        raise ValueError("order and position multipliers must have same length")
    return product(1.0 + raw_buffs[name] * position_chain_multipliers[i] for i, name in enumerate(order))


def rank_independent_buff_orders(raw_buffs: Mapping[str, float], position_chain_multipliers: Sequence[float]):
    rows = []
    for order in itertools.permutations(raw_buffs.keys()):
        rows.append((independent_buff_total(raw_buffs, order, position_chain_multipliers), "".join(order)))
    rows.sort(reverse=True)
    return rows


def resolve_party_atk(
    *,
    database_atk: float | None = None,
    party_screen_atk: float | None = None,
    bond_atk_flat_delta: float | None = None,
    intimacy_atk_flat_delta: float = 0.0,
) -> float:
    """Resolve ATK before /10; party-screen ATK already includes bond stats.

    Avoid reverse-engineering bond stat growth. Provide observed flat delta if
    only the database ATK is available, or prefer party_screen_atk as-is.
    """
    if party_screen_atk is not None:
        if bond_atk_flat_delta is not None or intimacy_atk_flat_delta != 0:
            raise ValueError("party_screen_atk already includes visible bond/intimacy stats; do not add them again")
        if party_screen_atk < 0:
            raise ValueError("ATK must be nonnegative")
        return party_screen_atk
    if database_atk is None:
        raise ValueError("provide party_screen_atk or database_atk")
    if bond_atk_flat_delta is None:
        raise ValueError("missing bond ATK delta; use party_screen_atk or explicit bond_atk_flat_delta=0")
    value = database_atk + bond_atk_flat_delta + intimacy_atk_flat_delta
    if value < 0:
        raise ValueError("ATK must be nonnegative")
    return value


def weapon_attack_flat_damage(attack_gauges: int, tier: str = "normal") -> int:
    """Flat weapon attack bonus applied after attack-buff multipliers."""
    if isinstance(attack_gauges, bool) or not isinstance(attack_gauges, int) or attack_gauges < 0:
        raise ValueError("attack_gauges must be a nonnegative integer")
    per_gauge = {"normal": 100, "plus": 130, "plus_plus": 170}
    if tier not in per_gauge:
        raise ValueError("tier must be normal, plus, or plus_plus")
    return attack_gauges * per_gauge[tier]


def normal_hit_with_weapon(basic_damage: float, weapon_flat_damage: float = 0.0, chronicle_bonus: float = 0.0, debuff_multiplier: float = 1.0) -> int:
    return math.floor((basic_damage + weapon_flat_damage + chronicle_bonus) * debuff_multiplier)


def critical_hit_with_weapon(basic_damage: float, crit_mult: float, weapon_flat_damage: float = 0.0, chronicle_bonus: float = 0.0, debuff_multiplier: float = 1.0) -> int:
    return math.floor((basic_damage * crit_mult + weapon_flat_damage + chronicle_bonus) * debuff_multiplier)


def expected_dps(normal_cycle_damage: float, critical_cycle_damage: float, critical_probability: float, attack_interval_seconds: float) -> float:
    """Uses final critical probability, not summed equipment gauge counts."""
    if not 0.0 <= critical_probability <= 1.0:
        raise ValueError("critical_probability must be in [0,1]")
    if attack_interval_seconds <= 0:
        raise ValueError("attack_interval_seconds must be >0")
    return ((1.0-critical_probability) * normal_cycle_damage + critical_probability * critical_cycle_damage) / attack_interval_seconds


def attack_basic_damage(
    atk: float,
    multiplicative_buffs: Sequence[float] = (),
    additive_buffs: Sequence[float] = (),
    resonance_buffs: Sequence[float] = (),
    separate_additive_sources: Sequence[float] = (),
) -> float:
    base = math.floor(atk / 10.0)
    m = product(1.0 + x for x in multiplicative_buffs)
    a = min(sum(additive_buffs), 1.0)
    r = min(sum(resonance_buffs), 1.0)
    e = product(1.0 + x for x in separate_additive_sources)
    return base * m * (1.0 + a + r) * e


def crit_multiplier(
    multiplicative_values: Sequence[float] = (),
    additive_values: Sequence[float] = (),
    resonance_values: Sequence[float] = (),
    separate_values: Sequence[float] = (),
) -> float:
    return (
        1.5
        + sum(multiplicative_values)
        + min(sum(additive_values), 1.0)
        + min(sum(resonance_values), 1.0)
        + sum(min(x, 1.0) for x in separate_values)
    )


def pursuit_hit(basic_damage: float, pursuit_mult: float) -> int:
    return math.ceil(basic_damage * pursuit_mult)


def _parse_buff(s: str):
    name, value = s.split("=", 1)
    return name.strip(), float(value) / 100.0


def cmd_rank(args):
    buffs = dict(_parse_buff(x) for x in args.buff)
    # Simplified homogeneous chain: first has no next-chain bonus; positions 2+
    # receive the same combined bonus. Separate flags are kept to prevent the
    # conceptual Mana/Button conflation.
    pos = []
    for i in range(len(buffs)):
        if i == 0:
            pos.append(chain_multiplier(i))
        else:
            pos.append(chain_multiplier(i, pending_mana_bonus=args.mana_chain/100.0, pending_button_bonus=args.button_chain/100.0))
    rows = rank_independent_buff_orders(buffs, pos)
    best_v, best_o = rows[0]
    worst_v, worst_o = rows[-1]
    print("position_chain_multipliers:", ", ".join(f"{x:.6g}" for x in pos))
    print(f"best  {best_o}: {best_v:.12f}")
    print(f"worst {worst_o}: {worst_v:.12f}")
    print(f"best/worst - 1: {(best_v/worst_v-1)*100:.9f}%")
    print(f"loss worst vs best: {(1-worst_v/best_v)*100:.9f}%")
    for o in args.order:
        v = independent_buff_total(buffs, tuple(o), pos)
        print(f"order {o}: {v:.12f}; vs best loss={(1-v/best_v)*100:.9f}%")


def cmd_selftest(_args):
    buffs = {"A":2.7,"B":0.8,"C":0.7,"D":0.65,"E":0.6}
    pos = [1.0,3.5,3.6,3.7,3.9]
    assert abs(independent_buff_total(buffs, "EDCBA", pos) - 842.16743424) < 1e-9
    assert abs(independent_buff_total(buffs, "EDCAB", pos) - 835.15841024) < 1e-9
    assert abs(independent_buff_total(buffs, "EADCB", pos) - 825.98926784) < 1e-9
    assert abs(independent_buff_total(buffs, "ABCDE", pos) - 562.84857024) < 1e-9
    ares = 2350*12.5*1.5*(3.9+2)*4*1.325*1.125/1.5
    assert abs(ares - 1033375.78125) < 1e-9
    assert abs(amplify_effect(.50, 1.4, 1.15) - .805) < 1e-12
    assert [extra_button_bonus_by_breakthrough(i) for i in range(5)] == [0.32, 0.34, 0.36, 0.38, 0.4]
    assert abs(chain_multiplier(4, pending_button_bonus=6*.32+extra_button_bonus_by_breakthrough(4)) - 3.82) < 1e-12
    assert abs(skill_power_multiplier([.06, .01, .05]) - 1.12413) < 1e-12
    assert resolve_party_atk(party_screen_atk=28000) == 28000
    assert resolve_party_atk(database_atk=26500, bond_atk_flat_delta=1500) == 28000
    try:
        resolve_party_atk(party_screen_atk=28000, bond_atk_flat_delta=1500)
        raise AssertionError("double counting of bond ATK must be rejected")
    except ValueError:
        pass
    assert weapon_attack_flat_damage(5) == 500
    assert weapon_attack_flat_damage(5, "plus") == 650
    assert weapon_attack_flat_damage(5, "plus_plus") == 850
    assert normal_hit_with_weapon(2800*1.5, weapon_attack_flat_damage(5)) == 4700
    assert critical_hit_with_weapon(2800*1.5, 1.75, weapon_attack_flat_damage(5)) == 7850
    assert abs(product([1.15,1.10,1.03]) - 1.30295) < 1e-12
    assert abs(skill_power_multiplier([.15,.05])-1.2075) < 1e-12
    assert abs(amplify_effect(.60, 1.10, skill_power_multiplier([.15,.05]))-.79695) < 1e-12
    assert abs(expected_dps(1000, 2000, .40, 2.0) - 700) < 1e-9
    print("selftest: OK")


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("rank-buffs", help="rank independent multiplicative skill-buff orders")
    r.add_argument("--buff", action="append", required=True, help="NAME=PERCENT, e.g. A=270")
    r.add_argument("--mana-chain", type=float, default=0.0, help="fixed next-skill Mana Chain bonus in percent")
    r.add_argument("--button-chain", type=float, default=0.0, help="fixed next-skill Button bonus in percent")
    r.add_argument("--order", action="append", default=[], help="specific order to print, e.g. EDCBA")
    r.set_defaults(func=cmd_rank)
    s = sub.add_parser("selftest")
    s.set_defaults(func=cmd_selftest)
    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
