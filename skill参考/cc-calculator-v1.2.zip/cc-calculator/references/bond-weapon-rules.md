# 羁绊（絆）与武器（武器）——伤害计算规则 v1.2

## 总原则：来源 ≠ 乘区

羁绊、武器、觉醒、Extra、Leader 等是 **source**，不是独立的通用乘区。先读能力文字，决定 target、condition、effect 和 stack category；再按效果本身计算。

不要做 `all_bond_multiplier × all_weapon_multiplier` 这种粗暴运算；不同效果会落入不同位置。

## A. 羁绊的两层

### A1. 羁绊基础能力值提升 / 絆ステ

- 装备羁绊时，主卡面板 ATK/HP 会获得基础数值提升；比例可由羁绊角色的等级、稀有度、倾向、同所属奖励等决定（有历史公式，不要假定现代全部角色统一 10%/15%）。
- 最可靠输入是**编队页面已经显示的 ATK**，其已包含羁绊数值与亲爱度等已体现在该页面的属性。不得重复加一遍。
- 如果只有数据库的角色 ATK，则向用户索取实际羁绊提供的 ATK 增量（或编队 ATK），不要默认某个百分比。
- 常规基础伤害 `floor(effective_atk / 10)`；拳/双剑特殊规则另见 damage-rules.md。
- `effective_atk` 不是武器攻击格的固定伤害加值；后者另算。

### A2. 羁绊能力 / 絆アビリティ

装备羁绊后，获得羁绊能力效果（不要自动继承羁绊角色的全部普通觉醒/技能/Extra）。按能力原文和触发条件分类：

| 典型描述 | 计算类别 | 举例 |
|---|---|---|
| 战斗中自身攻击 +15% | 攻击乘算（常见） | `M *= 1.15` |
| 战场上队友攻击 +3% | 满足条件目标的攻击乘算光环（常见） | `M[target] *= 1.03` |
| 自身暴击威力 +15% | 暴击威力数值增加 | `crit_multiplier += .15` |
| 必杀技威力 +15% | 必杀威力 UP 独立乘区 | `skill_power_multiplier *= 1.15` |
| 按必杀按钮时，下一发 +X% | Button Chain Buff | 与下一发默认 Chain 加算，记录按钮触发及可否后备生效 |
| 消耗 Mana 时，下一发 +X% | Mana Chain Buff | 按实际消费触发；不要和 Button 混同 |
| 每次、一定时间、敌数变化等 | 可能加算、共鸣、别框等 | 按明确分类；不凭“羁绊”强制乘算 |

**目标与条件：** `self`、`front_party`、`all_battlefield_allies`、`backline_to_front` 等必须读取实际文字。羁绊所附角色所在编队位置、场上目标、所属和武器种类条件均可能影响生效。不能把“战场上队友”误解成后备一律生效。

**重要：** 羁绊效果的 `+15% 必杀威力` 可以增强可强化的主动技能攻击 Buff，但 `+15% 暴击威力` 不会被 Chain/必杀威力 UP 进一步放大。

## B. 武器三层

### B1. 武器攻击格 / 攻撃ボーナス（固定伤害）

普通攻击格当前参考值：

- 通常：每格 +100 最终攻击伤害；
- 攻击格 `+`：每格 +130；
- 攻击格 `++`：每格 +170。

`weapon_flat_damage = attack_gauges * (100 | 130 | 170)`。

日站给出的普通攻击 / 暴击 / 必杀公式，**在对应 Buff 乘区和暴击、技能倍率之后**加这个固定值，然后乘目标 Debuff 倍率：

```
normal_hit = floor((basic_damage + weapon_flat_damage + chronicle_bonus) * debuff_multiplier)
crit_hit   = floor((basic_damage * crit_multiplier + weapon_flat_damage + chronicle_bonus) * debuff_multiplier)
skill_hit  = floor((basic_damage * skill_raw_multiplier * chain_multiplier * skill_power_multiplier + weapon_flat_damage) * debuff_multiplier)
```

不要把武器攻击格当成 `ATK += 100 × 攻击格` 后再吃所有 Buff；也不要把攻击格误读成 +X% 攻击力。追击公式当前未加武器攻击格：`ceil(basic_damage * pursuit_multiplier)`。

### B2. 武器暴击格 / クリティカル率（概率，不是暴伤）

- 普通武器的“暴击格”提升**暴击发生率**。旧 Gamerch 资料为每格约 +0.5 个百分点；现代特殊武器属性需查具体说明。
- “暴击威力 +10%”来自**武器能力文字**时才进入 `crit_multiplier += 0.10`。
- 若算期望 DPS，用最终实际暴击概率 `p`：

```
expected_cycle_damage = (1-p) * normal_cycle_damage + p * crit_cycle_damage
expected_DPS = expected_cycle_damage / attack_interval_seconds
```

如果已假设全暴击，概率格不再提高该模型的满暴击伤害。

### B3. 武器能力 / 武器アビリティ

武器附带的能力与其他角色能力使用同一乘区规则，不能认为所有武器加成都是固定伤害：

| 武器能力 | 归属 |
|---|---|
| 攻击力 +7.5% | 通常攻击乘算 `×1.075`，需判断是否注明特殊别框 |
| Boss Wave 全队攻击 +5% | 满足 Boss Wave 时全队乘算光环 `×1.05`（按具体效果分类） |
| 暴击威力 +10% | 暴击倍率 `+0.10`，非暴击率 |
| 必杀威力 +5% | 与其他必杀 UP 乘算 `×1.05` |
| “下一发同Chain威力 +2%” | 依据“按按钮”或“耗 Mana”的文案加入下一发对应 Chain 加算池 |
| 特定敌人伤害 +20% | 特攻等特定目标/伤害类型乘区；未证实前单独记录，不强行归到普通攻击 Buff |

武器能力通常以**装备者**为触发主体或效果来源，但其作用对象由文本决定（可能全队）；不要将“攻击力增加”推定为全队效果，也不要将“全队效果”自动扩展至后备。

## C. 合并示例（假设确认各项条件生效）

- 羁绊攻击 +15%；武器能力攻击 +10%；来自队友的乘算光环 +3%：
  `M = 1.15 × 1.10 × 1.03 = 1.30295`。
- 羁绊暴击威力 +15%；武器能力暴击威力 +10%：
  `crit_multiplier = 1.5 + 0.15 + 0.10 = 1.75`（其他暴击来源暂不计）。
- 羁绊必杀威力 +15%；武器能力必杀威力 +5%：
  `skill_power_multiplier = 1.15 × 1.05 = 1.2075`。
- 若这些是强化 +60% 的普通可强化技能 Buff、1st Chain、无其他 Chain：
  `b_actual = 0.60 × 1.10 × 1.2075 = 0.79695`，最终该**乘算型**技能 Buff 为 `×1.79695`。暴击威力 +25% 不吃 Chain，也不进入这个 60% 攻击 Buff 数值。

## D. Skill 输入模型建议

```
main_actor:
    character_atk                # 来自数据库的原始 ATK，可选
    party_screen_atk             # 推荐直接使用。若有此值，禁止再手动加羁绊面板数值
bond:
    supporting_character_id
    stat_atk_delta               # 可选；需要以已验证数值录入
    abilities: []                # 羁绊能力，逐条标明 target、condition、category
weapon:
    name
    attack_gauges
    attack_gauge_type            # normal / plus / plus_plus
    crit_gauges                  # 影响概率；如全暴击可忽略
    abilities: []                # 武器被动逐条标明 target、condition、category
other_effect_sources:
    # main_passive/extra/leader/resonance/subparty/skill/bond/weapon ...
```

统一的效果组件应至少保留：

```
source_type, source_id, carrier_actor_id, target, stat, category,
value, trigger, condition, cap, duration, stack_key, active_in_subparty,
chain_scalable, skill_power_scalable, effect_scope
```

注意：**`source_type` 是元数据，不是计算乘区。** 同样 +5% 攻击光环，来自羁绊或武器时只要类别和条件相同，就进入同一个通用攻击乘算汇总，不新增独立的 “羁绊乘区” 或 “武器乘区”。

## E. 核验资料

- 现代普通攻击、暴击、武器攻击格公式：https://www.chainchro-kouryakuhonbu.com/calc-top/calcofattack/
- 羁绊基础属性与同职业效果：https://gamerch.com/chainchroniclewiki/419742
- 羁绊属性增长类型（历史，实际数值需校验）：https://gamerch.com/chainchroniclewiki/420003
- 羁绊全队光环：https://www.chainchro-kouryakuhonbu.com/matome/kizunamatome/kessoku/
- 羁绊必杀威力/Button Buff：https://www.chainchro-kouryakuhonbu.com/matome/kizunamatome/hissatuup/
- 武器火力类被动：https://www.chainchro-kouryakuhonbu.com/matome/abilityweapon/attack/
- 武器辅助类被动：https://www.chainchro-kouryakuhonbu.com/matome/abilityweapon/support/
- 武器普通暴击格：https://gamerch.com/chainchroniclewiki/421202

## F. 尚需单卡验证

- 羁绊具体角色的 `ATK` 属性数值如何由等级、同所属、特定系统换算，以编队面板为准。
- 少量特殊武器改变攻击格/暴击格效果；按具体武器覆写常规规则。
- 武器特攻、属性克制、条件光环和羁绊的少见特殊乘区；不要未查即硬编码。
