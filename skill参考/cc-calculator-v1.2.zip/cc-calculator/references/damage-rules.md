# Damage Rules

## 1. 攻击力 Buff 分类

### 乘算 Buff

```text
M = Π(1 + m_i)
```

例：+100% 与 +50%：

```text
2.0 × 1.5 = 3.0
```

### 普通加算 Buff

```text
A = min(sum(a_i), 1.0)
```

攻击加算上限当前按 100%。

### 共鸣 Buff

```text
R = min(sum(r_i), 1.0)
```

共鸣攻击 Buff 有独立 100% 上限。

普通加算与共鸣最终放在同一个括号：

```text
1 + A + R
```

因此二者都满时可得到 `×3.0`。

### 别框加算 Buff

同一来源内部先加：

```text
e_j = min(sum(stacks_from_same_source), source_cap)
```

不同来源彼此乘：

```text
E = Π(1 + e_j)
```

例：来源1 +20%，来源2 +18%：

```text
1.20 × 1.18 = 1.416
```

不是 `1.38`。

## 2. 基本伤害

常规：

```text
base_stat_damage = floor(ATK / 10)
```

攻击 Buff 后：

```text
basic_damage = base_stat_damage × M × (1 + A + R) × E
```

### 拳/双剑特殊基础伤害

现代攻略记录普通攻击存在：

```text
round(ATK × 0.55 / 10)
```

的特殊基础伤害规则。

由于具体武器/攻击段结构会影响实际每 Hit 解释，计算角色前必须先确认武器类型与攻击方式；若题目只是在比较 Buff 倍率，不需要引入此特殊项。

## 3. 武器/列传/敌方 Debuff

武器攻击格为每格固定伤害：普通 +100、攻击格+ +130、攻击格++ +170；不同于面板 ATK，不能在基础伤害前当作 ATK 叠加。武器暴击格主要提高暴击发生率而非暴击威力。武器/羁绊的**能力附加效果**需按自身分类进入其他乘区，参见 `bond-weapon-rules.md`。

普通攻击：

```text
normal_hit = floor((basic_damage + weapon_bonus + chronicle_bonus) × debuff_multiplier)
```

敌方 Debuff：

```text
debuff_total = min(sum(debuff_i), 1.0)
debuff_multiplier = 1 + debuff_total
```

## 4. 暴击

基础暴击倍率：

```text
1.5
```

暴击威力 Buff 的计算方式与攻击力 Buff 不同：无论它的来源属于“乘算/加算/共鸣/别框加算”，最终都是把对应**暴击威力数值**加到 1.5 上。

```text
crit_multiplier = 1.5
  + sum(crit_multiplicative_values)
  + min(sum(crit_additive_values), 1.0)
  + min(sum(crit_resonance_values), 1.0)
  + sum(each_capped_crit_separate_additive_source)
```

注意：这里的“乘算型暴击威力 +200%”贡献是 `+2.0`，不是 `×3.0`。

单段暴击：

```text
crit_hit = floor((basic_damage × crit_multiplier + weapon_bonus + chronicle_bonus)
                 × debuff_multiplier)
```

## 5. 多段暴击

如果角色暴击变成 `N` 连击，且每段倍率都相同：

```text
crit_cycle_without_pursuit = N × crit_hit
```

若具体角色各段倍率不同，必须逐段算，不能用 N 直接乘。

## 6. 追击

单个追击效果：

```text
pursuit_hit = ceil(basic_damage × pursuit_multiplier)
```

多个追击效果若彼此独立：

```text
pursuit_per_trigger = sum(each pursuit_hit)
```

当前已有实算支持：普通攻击为多段暴击、且追击按每个暴击 Hit 触发时：

```text
cycle_damage = crit_hit_count × (crit_hit + pursuit_per_trigger)
```

例如暴击 4 段、每段附 1倍追击×2：

```text
pursuit triggers = 4 × 2 = 8 次
```

角色文本若明确存在不同触发频率，覆盖此默认。

## 7. DPS

```text
DPS = damage_per_attack_cycle / attack_interval_seconds
```

攻速变化应直接改变 `attack_interval_seconds`。

不要把一个 Buff 倍率如 `×1.125`误认成攻速，仅因为它出现在 `/1.5` 前面。

## 8. 按钮必杀伤害

```text
skill_damage = floor(
  (basic_damage
   × skill_multiplier
   × chain_multiplier
   × skill_power_multiplier
   + weapon_bonus)
  × debuff_multiplier
)
```

### Skill multiplier vs Skill power UP

- `skill_multiplier`：该必杀本身的固定倍率，例如 5倍。
- `skill_power_multiplier`：能力/Leader 等“必杀威力 +X%”的额外乘区。

不要混为一个值。

## 9. 自动技能

原则公式：

```text
auto_skill_damage = floor(
  (basic_damage × skill_multiplier + weapon_bonus)
  × debuff_multiplier
)
```

默认不吃 Chain 与必杀威力 UP。

已知例外：

- 共鸣自动技能由角色自己的当前必杀满足触发条件时，可继承该发 Chain。
- 某些“不会强化 Buff”的必杀威力 UP 可强化自动技能伤害。

必须以具体能力文本/实测设置 flags：

```text
affects_button_skill_damage
affects_skill_buff
affects_auto_skill_damage
```

## 10. 技能 Buff 强化

可强化组件：

```text
actual_buff = raw_buff × chain_multiplier × skill_power_multiplier
```

之后再进入其原始乘区。

当前默认：

| 组件 | Chain/必杀威力强化 |
|---|---|
| 攻击 Buff | 可（除固定/特殊） |
| 防御 Buff | 可（除固定/特殊） |
| 暴击威力 Buff | 不可 |
| 追击倍率 | 不可 |
| 普通 Debuff | 原则不可 |
| 无伤害领域 Debuff | 有确认可强化例外 |
| 自动技能附带 Buff | 原则不可 |

## 11. 覆盖

同一 actor 的同一技能 Buff 默认后发覆盖前发。

```text
active_skill_buff[(actor_id, stack_key)] = latest
```

自有角色和好友同名角色使用不同 actor_id。

## 12. 取整

已确认：

- 常规 `ATK/10` 基础伤害：向下取整。
- 普通攻击最终伤害：向下取整。
- 暴击最终伤害：向下取整。
- 按钮必杀最终伤害：向下取整。
- 追击最终伤害：向上取整。
- 拳/双剑特殊基础伤害：资料记载为四舍五入。

尚未完全确认：所有中间乘区之间是否存在额外截断点。

因此除上述节点外，第一版计算保持完整精度，到已确认节点再取整。
