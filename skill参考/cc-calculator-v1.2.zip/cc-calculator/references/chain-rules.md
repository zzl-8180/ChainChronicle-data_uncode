# Chain Rules

## 1. Default Chain

| 当前技能序号 | 名称 | 默认加成 | 默认 Chain multiplier |
|---:|---|---:|---:|
| 1 | Chain 起点 | 0% | 1.00 |
| 2 | 1stChain | 10% | 1.10 |
| 3 | 2ndChain | 20% | 1.20 |
| 4 | 3rdChain | 30% | 1.30 |
| 5+ | MAXChain | 50% | 1.50 |

同一 Chain 中达到 MAX 后，后续仍为 50%。有第六名不同角色参与时可以再次得到 MAXChain。

## 2. Mana Chain Buff vs Button Buff

这两个必须单独记录。

### Mana Chain Buff

识别关键词：

```text
味方がマナを消費すると
每次我方消耗法珠/Mana时
```

触发：本发**实际消耗** Mana。

效果：同一 Chain 内“下一发”必杀的 Chain 加成增加。

### Button Buff

识别关键词：

```text
味方が必殺ボタンを使用して必殺技を発動すると
每次我方使用必杀按钮发动必杀技时
```

触发：通过必杀按钮发动。

效果：同一 Chain 内“下一发”必杀的 Chain 加成增加。

Button 型覆盖的触发场景更广：0 Mana 但仍按按钮的技能可触发 Button，不触发 Mana 型。

### Extra Button Buff：突破档位而不是多个效果

文案：`同Chain内下次使用必杀技威力（32/34/36/38/40%）增加。此效果在后备队伍时也能发动`。

这里括号内的 **五个**值按突破数从 0 到 4 一一对应：

| 突破数 | 本卡 Button Buff | 
|---:|---:|
| 0破 | +32% |
| 1破 | +34% |
| 2破 | +36% |
| 3破 | +38% |
| 4破（满破） | +40% |

任意一张卡只能取一个档位；同来源不得将五个数值相加。虽可在后备触发此 Button Buff，但其他能力仍需单独确认后备生效范围。

和 `2.5/5/7.5/10%` **四个 Chain 阶段**的写法完全不同：后者按下一发 Chain 档位取值。

示例：5 前场 + 2 后备，一名满破候选 +40%，其余 6 人假设全部 0 破 +32%，且七人 Button Buff 都符合触发条件：`6×0.32 + 0.40=2.32`；MAX `1+0.50+2.32=3.82`。

### 叠加

两者数值都与默认 Chain **加算**，彼此也加算：

```text
1stChain + Mana 100% + Button 140%
= 10% + 100% + 140%
= 250% bonus
= ×3.50
```

## 3. “下一发”不是持续累积

如果队伍拥有合计 +240% 的 next-chain 能力，且每一发都满足触发条件，那么每发都会重新给下一发 +240%。

它不是：

```text
第2发 +240%
第3发 +480%
第4发 +720%
```

而是每一发的下一发分别得到同一组当前可触发能力的总和。

## 4. Scaled next-chain bonus

数据库中存在：

```text
每次我方使用必杀按钮发动必杀技时，
同Chain内下次使用必杀技威力（2.5/5/7.5/10%）增加，
根据Chain数[对应1st/2nd/3rd/MaxChain]效果上升
```

内部保存为：

```text
button_chain_scaled_bonus = {
  1st: 0.025,
  2nd: 0.050,
  3rd: 0.075,
  max: 0.100
}
```

若多个来源同时存在，按当前下一发的 Chain 档位取值后相加。

## 5. Instant Chain bonus / 万象 Mana

与 Mana Chain Buff 不同。

当前采用已支持规则：使用万象 Mana 的**本发**得到即时 +10% Chain 修正。

因此：

```text
0Chain + universal mana: ×1.10
MAX + fixed next-chain 240% + universal mana:
1 + 50% + 240% + 10% = ×4.00
```

不要因为名字里有“Mana”就把它归入“消耗 Mana 后强化下一发”的 Mana Chain Buff。

## 6. 0 Mana / 超共鸣 / 英雄技

原则：

- `mana_consumed == 0`：不触发 Mana Chain Buff。
- `uses_skill_button == true`：触发 Button Buff。
- 英雄技/0 Mana 技能是否参与 Chain，按具体机制；已确认的英雄技参与 Chain 且可用额外角色形成第二个 MAX。

“原本有费用，但因减费变成实际 0 Mana”是否完全等同 0 Mana 的触发判定，目前标记为 `PROVISIONAL`，见 evidence。

## 7. Chain Break

普通规则：同一角色在同 Chain 中再次发动会断链；超过接续窗口也断链。

Chain 断开后：

```text
chain_index = 0
pending_mana_chain_bonus = 0
pending_button_chain_bonus = 0
pending_scaled_bonus = 0
```

接续时间延长能力不影响伤害公式，只影响时间窗口；具体秒数若资料未知，不猜。

## 8. Buff amplification

对于可强化的技能效果：

```text
chain_multiplier = 1 + all_chain_bonus
skill_power_multiplier = product(1 + each_skill_power_up)
actual_effect = raw_effect × chain_multiplier × skill_power_multiplier
```

示例：原攻击 Buff 50%，本发 Chain 总加成 40%，必杀威力 UP 15%：

```text
50% × 1.4 × 1.15 = 80.5%
```

最终若为乘算攻击 Buff：

```text
×(1 + 80.5%) = ×1.805
```

## 9. +240% 简化模型

若第一发没有 pending bonus，之后每发都触发固定 +240%，且五发都是不同角色：

```text
位置1: 1.00
位置2: 1 + 10% + 240% = 3.50
位置3: 1 + 20% + 240% = 3.60
位置4: 1 + 30% + 240% = 3.70
位置5: 1 + 50% + 240% = 3.90
```

这个模型只在 Mana/Button 触发条件对每一步都相同时成立。若某一步 0 Mana，只应移除由该步触发给下一发的 Mana 型部分。
