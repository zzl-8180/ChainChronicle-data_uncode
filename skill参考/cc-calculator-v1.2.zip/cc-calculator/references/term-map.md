# Calculation Term Map

仅收录会改变计算路径的术语。翻译措辞仍以 `cc-translator` 为主。

| 日文/中文关键词 | 内部类型 | 计算提示 |
|---|---|---|
| 味方がマナを消費すると / 每次我方消耗法珠时 | mana_chain_trigger | 实际消耗 Mana 才给下一发 |
| 必殺ボタンを使用して / 使用必杀按钮 | button_chain_trigger | 按按钮给下一发；0 Mana 也可 |
| 同じChain内で次に使用する必殺技 | next_chain_effect | 只作用下一发，不累计到更后面 |
| Chainによる威力の上昇量 | chain_bonus | 归 Chain 加算区 |
| （32/34/36/38/40%）增加 / 32~40%(BB) | button_bonus_by_limit_break | 五个值分别是 0/1/2/3/4 破；单卡取一个；不是把五个叠加，也不是 Chain 阶段 |
| 必殺技威力up / 必杀技威力增加 | skill_power_up | 独立乘区；多个彼此乘 |
| 固定 | fixed_effect | 不被 Chain/skill power 放大 |
| ～たび / 每次…时 | often additive | 只作提示，不可仅凭此定乘区 |
| 共鳴アビリティ / 共鸣能力 | resonance | 共鸣 Buff 池，攻击上限单独 100% |
| 攻撃するたび / 每次攻击 | often separate_additive | 常见别框加算，但需资料确认 |
| 敵の数が多いほど | often separate_additive | 常见别框加算 |
| クリティカル威力 / 暴击威力 | crit_power | 最终加到基础暴击 1.5 |
| 追撃 / 追击 | pursuit | `basic_damage × pursuit倍率`，最终 ceil |
| 自動スキル / 自动技能 | auto_skill | 默认无 Chain/skill power |
| 領域 / 领域 | field_effect | 领域 Buff 常见加算；无伤害领域 Debuff 可存在 Chain 强化例外 |
| 1stChain以上で効果上昇 | raw_skill_variant | 先切换原始技能值，再做 Chain 强化 |
| 万象マナ / 万象法珠 | universal_mana | 本发即时 Chain 修正需单独处理 |
| 超共鳴必殺 / 超共鸣必杀 | zero_mana_skill candidate | 常见 0 Mana；仍需看具体文本确认按钮/费用 |
| 絆アビリティ / 羁绊能力 | source:bond_ability | 按效果归属乘区；与羁绊基础 ATK 属性不同 |
| 絆ステ / 羁绊属性增加 | stat:bond_atk | 先纳入面板 ATK；面板已含时不得重复计算 |
| 武器アビリティ / 武器能力 | source:weapon_ability | 逐条分类，不是统一固定伤害 |
| 攻撃ボーナス / 武器攻击格 | weapon_flat_damage | 通常每格固定 +100，+每格130，++每格170 |
| クリティカル率 / 武器暴击格 | crit_chance | 概率，不是暴击威力 +X% |
| LEADER能力 | passive source | 可能提供攻击/必杀威力/追击等独立来源 |
| 別枠加算バフ | separate_additive | 同源内部加，不同来源乘 |
| 加算バフ | additive | 攻击池一般上限100% |
| 乗算バフ | multiplicative | 攻击 Buff 彼此乘 |

## 文本解析纪律

不要仅依据“常驻/时效/一定时间”判断乘区。

优先级：

1. 已有攻略/数据库明确分类。
2. 角色实测。
3. 可靠的文本模式提示。
4. 不确定时标记 `UNKNOWN`。

## 推荐效果组件字段

```text
value
source_type           # bond_ability / weapon_ability / passive / ...
carrier_actor_id
target
stat                  # attack / defense / crit_power / pursuit / skill_damage ...
category              # multiplicative / additive / resonance / separate_additive
source_actor_id
ability_id
stack_key
cap
condition
duration
chain_scalable
skill_power_scalable
fixed
```
