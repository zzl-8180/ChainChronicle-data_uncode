# Evidence & Open Questions

更新时间：2026-10-08

## A. 核心来源

### Chain Chronicle 攻略本部 — Buff 分类

URL: https://www.chainchro-kouryakuhonbu.com/calc-top/kindofbuff/

当前可确认：

- 加算 / 共鸣 / 别框加算 / Chain Buff 的区分。
- 普通加算攻击上限 100%。
- Chain Buff 分 Mana Chain 与 Button Buff。
- Mana 型关键词“マナを消費”；Button 型关键词“必殺ボタン”。
- Button Buff 覆盖触发范围更广。
- 当前未确认 Chain Buff 总上限。

等级：`CONFIRMED`

### Chain Chronicle 攻略本部 — 必杀计算

URL: https://www.chainchro-kouryakuhonbu.com/calc-top/calcofskill/

当前可确认：

- 默认 Chain：10/20/30/50%。
- 能力 Chain Buff 与默认 Chain 加算。
- 必杀威力 UP 多个彼此乘算。
- 按钮必杀伤害公式。
- 自动技能原则不吃 Chain/必杀威力 UP，以及两类例外。
- 可强化技能 Buff：`raw buff × Chain × skill power`。
- 当前验证范围内主要攻击/防御 Buff 可强化；暴击威力/追击倍率不强化。
- 普通 Debuff 原则不强化；无伤害领域 Debuff 有例外。
- 中间截断时点仍在调查。

等级：`CONFIRMED`

### Chain Chronicle 攻略本部 — 普攻计算

URL: https://www.chainchro-kouryakuhonbu.com/calc-top/calcofattack/

当前可确认：

- 常规基础伤害 `floor(ATK/10)`。
- 拳/双剑普通攻击基础值存在 `ATK×0.55/10` 四舍五入规则。
- 攻击基础乘区：乘算 × (加算+共鸣) × 别框。
- 普通加算/共鸣各自 100% 上限。
- 别框同来源内部加，不同来源乘。
- 暴击倍率从 1.5 开始，各类暴击威力数值加入倍率。
- 追击 `basic_damage × pursuit`，最终向上取整。

等级：`CONFIRMED`

### 用户提供：2018 百度贴吧《觉醒等自身加成的分类及计算(重发)》

历史分类：

1. 乘算型。
2. 加算型（同池加，上限100%）。
3. 独立加算型（当前可对应“别框加算”的早期玩家分类）。

这与现代攻略体系高度一致，可用来解释旧卡/旧帖术语。

等级：`SUPPORTED / historical`

### 用户提供：现代贴吧“角色单卡DPS计算（萌新进阶篇）”截图

用于回归测试大正义、洛蕾塔、万象研究者等计算式。

注意：“DPS”在部分帖子中有时把“一轮完整攻击伤害”和严格每秒伤害混用；本 skill 永远显式输出 attack cycle 与 interval。

等级：`SUPPORTED / user-provided`

### Koncoo 数据库

URL: http://att.koncoo.com/cc/db/Index.aspx

用户指定作为角色数据/字段的重要来源。网络抓取可能偶发失败；失败时使用用户贴出的数据库内容或截图，不要猜。

等级：数据源优先，但单个字段仍需结合实测/攻略判断乘区。

### 用户确认：Extra `32/34/36/38/40%` 的分级语法

来源：用户提供 Koncoo 角色截图与数据库翻译文案；2026-10-08 明确补充说明。

- 括号内依次代表 **0/1/2/3/4 破**，单卡只取当前一档。
- “后备队伍时也能发动”仅适用于文本明确允许的效果，不代表全体能力在后备生效。
- 与 1st/2nd/3rd/MAX 的四阶段 Chain 加成要严格分开。

等级：`CONFIRMED / user-provided`。

### 羁绊与武器规则（v1.2）

新增 `bond-weapon-rules.md`，分别涵盖羁绊基础面板数值、羁绊能力、武器固定攻击格、武器暴击概率格、武器附带能力：

- `https://www.chainchro-kouryakuhonbu.com/calc-top/calcofattack/`：攻击格常规每格 +100/+130/+170、加在 Buff 后；暴击/必杀公式。
- `https://gamerch.com/chainchroniclewiki/419742`：羁绊基本属性 + 同职业羁绊能力区分。
- `https://gamerch.com/chainchroniclewiki/420003`：羁绊基础属性依类型、等级与所属变化（历史参考，现代具体数值优先面板）。
- `https://www.chainchro-kouryakuhonbu.com/matome/kizunamatome/kessoku/`：羁绊可提供全队攻击光环及暴击威力。
- `https://www.chainchro-kouryakuhonbu.com/matome/kizunamatome/hissatuup/`：羁绊可提供必杀威力 UP / Button Buff。
- `https://www.chainchro-kouryakuhonbu.com/matome/abilityweapon/attack/`：武器被动可增攻、暴击威力、别框加算。
- `https://www.chainchro-kouryakuhonbu.com/matome/abilityweapon/support/`：武器被动可提供必杀威力 UP / Button Buff / 全队光环。
- `https://gamerch.com/chainchroniclewiki/421202`：普通武器暴击格作用于暴击率（历史一般为每格 +0.5 个百分点）。

`CONFIRMED`：来源 ≠ 乘区、羁绊能力/武器能力按效果分类、武器固定攻击格计算位置、普通武器暴击格不是暴伤。

`NEEDS CHARACTER DATA`：现代特殊羁绊属性的实际数值、特例武器格与部分条件/特攻的精确乘区；必须显式输入或查实。

## B. 已支持的边角机制

### 多段暴击与追击

已有社区实算支持“每个暴击 Hit 都触发追击”的角色结构；因此像暴击4段、每段2次追击，可产生8次追击。

等级：`SUPPORTED`，角色机制可 override。

### 同角色技能 Buff 覆盖

默认同 actor 的技能 Buff 后发覆盖前发；好友同名卡作为不同 actor 可共存。

等级：`CONFIRMED`（存在少数未展开例外）。

### 英雄角色带来的额外 MAX

允许更多不同 actor 进入同一 Chain，因此第 5、6 发都可处于 MAX；MAX 默认仍为 50%。

等级：`SUPPORTED`。

## C. 尚未完全确认

### 1. 减费到实际 0 Mana 时的 Mana Chain 触发

逻辑上 Mana Chain 文案要求“消耗 Mana”，因此实际消耗 0 应不触发。

但目前缺专门针对“原本有费用，被减到0”的直接实测。

等级：`PROVISIONAL`

处理：若结果敏感，给出“触发/不触发”两个情景；否则明确采用“按实际消耗量判断”的假设。

### 2. Chain 接续时间延长的具体秒数

确认存在延长能力，但不同数据库/资料未给可靠统一秒数。

等级：`UNKNOWN`

处理：不影响倍率计算；若用户问操作窗口再专项查。

### 3. 同角色 Buff 覆盖的极少数例外

攻略明确提示“存在例外”，但未列出完整清单。

等级：`UNKNOWN`

处理：默认覆盖；有具体角色时检索实测或允许 `stack_override`。

### 4. 中间步骤取整

最终 floor/ceil 节点已知，但乘区之间是否存在额外截断仍在调查。

等级：`UNKNOWN`

处理：中间保留高精度，最终在已知节点取整；输出注明理论值可能与游戏实际相差少量整数。

## D. 不要固化为规则的“经验判断”

以下只能作为启发，不可当判定：

- “有一定时间 = 加算”。
- “常驻 = 乘算”。
- “每次/たび = 一定是加算”。
- “所有领域都是加算”。
- “所有 Debuff 都不能吃 Chain”。

它们都有例外或历史差异。
