# Regression Tests

修改计算规则后至少复核这些案例。

## Test 1 — +240% Chain，ABCDE Buff 排序

输入：

```text
A = +270%
B = +80%
C = +70%
D = +65%
E = +60%
```

假设：

- 五个 Buff 互为独立乘算。
- 第一发无 pending next-chain bonus。
- 后续每发都稳定得到固定 next-chain +240%。
- 无 skill power UP、无 scaled bonus、无 universal mana。

位置 Chain multiplier：

```text
[1.0, 3.5, 3.6, 3.7, 3.9]
```

### EDCBA

```text
E: 1 + 0.60×1.0 = 1.60
D: 1 + 0.65×3.5 = 3.275
C: 1 + 0.70×3.6 = 3.52
B: 1 + 0.80×3.7 = 3.96
A: 1 + 2.70×3.9 = 11.53
```

期望：

```text
total = 842.16743424
```

### EDCAB

```text
E,D,C same
A at 3rd: 1 + 2.70×3.7 = 10.99
B at MAX: 1 + 0.80×3.9 = 4.12
```

期望：

```text
total = 835.15841024
EDCBA / EDCAB - 1 = 0.8392448563% ≈ 0.84%
```

### A at 1st: EADCB

期望：

```text
total = 825.98926784
loss vs EDCBA = 1.9210154349% ≈ 1.92%
```

### 完全反向 ABCDE

期望：

```text
total = 562.84857024
EDCBA / ABCDE - 1 ≈ 49.63%
```

## Test 2 — Buff 都在 60–70%

输入：

```text
A=70%
B=67.5%
C=65%
D=62.5%
E=60%
```

同样使用 `[1.0,3.5,3.6,3.7,3.9]`。

期望：

```text
EDCBA = 222.22002795
ABCDE = 211.23215753125
best/worst relative gap = 5.2017981292% ≈ 5.20%
```

若固定 E 第一，后四人反排：

```text
EABCD = 221.61187125
EDCBA / EABCD - 1 ≈ 0.274%  (约0.27%)
```

用途：验证“大额 next-chain 加成会压平 1st–MAX 的相对差距，但 0Chain 仍是断层”。

## Test 3 — 必杀 Buff 强化

输入：

```text
raw attack buff = 50%
Chain bonus = 40%  => chain multiplier 1.4
skill power UP = 15% => 1.15
```

期望：

```text
actual buff = 50% × 1.4 × 1.15 = 80.5%
final multiplicative factor (if multiplicative attack buff) = 1.805
```

不得算成 `(1+50%)×1.4×1.15`。

## Test 4 — 大正义（用户提供现代帖回归）

帖子公式：

```text
2350 × 12.5 × 1.5 × (3.9 + 2) × 4 × 1.325 × 1.125 / 1.5
```

期望：

```text
1,033,375.78125
```

解释：

- 2350 = 23500/10。
- 12.5 = 自身攻击 +1150% => ×12.5。
- 1.5 = 全体攻击 +50% => ×1.5。
- 3.9 = 暴击倍率。
- +2 = 每个暴击 Hit 的两次 1倍追击总量。
- ×4 = 暴击4段；追击也按每段触发，因此总追击8次。
- ×1.325 = 条件攻击 +32.5%。
- ×1.125 = 别框加算在该场景下 +12.5%。
- /1.5 = 实际攻击间隔 1.5秒。

注意：这个回归式沿用帖子连续浮点乘算，没有插入游戏内部每 Hit floor/ceil；若要求“精确游戏显示整数伤害”，应按现代取整规则逐段算。

## Test 5 — Mana vs Button

假设队伍能力：

```text
Mana next-chain = +100%
Button next-chain = +140%
```

上一发普通 1 Mana 按钮必杀：下一发 1stChain：

```text
1 + 10% + 100% + 140% = 3.50
```

上一发 0 Mana 按钮必杀：下一发 1stChain：

```text
1 + 10% + 140% = 2.50
```

这个测试用于防止把两种 Chain 合并成一个无法判断触发的 `chain_bonus`。


## Test 6 — Extra 突破档位与必杀威力 UP 来源叠加

用户确认文案 `32/34/36/38/40%` 是同一卡 0～4 破的五个档位。

```text
for breakthrough in 0,1,2,3,4:
  chosen Button Buff = 32%,34%,36%,38%,40% respectively
```

示例：六张 0 破其他角色与一张 4 破候选，且后备效果文本允许：

```text
fixed Button Buff = 6×32%+40% = 232%
MAXChain = 1 + 50% + 232% = 3.82
```

必杀威力 UP（例 LA +6%、LS +1%、全队觉醒 +5%）同时作用时：

```text
skill_power_multiplier = 1.06×1.01×1.05 = 1.12413
not 1+6%+1%+5% = 1.12
```

这不能与“攻击 Buff 的加算池”概念混淆。


## Test 7 — 羁绊/武器基础属性与能力不混算 (v1.2)

- 初始角色 ATK `26500`，若编队面板含羁绊增量后显示 `28000`，则基础伤害 `floor(28000/10)=2800`，不得再次加 1500。
- 装备普通攻击格 5 格：`weapon_flat_damage=5*100=500`；攻击乘算 +50% 时普通攻击应为 `2800*1.5+500=4700`（无其他 Buff）。不能先给 ATK 加 500 再乘 1.5。
- 羁绊攻击+15%，武器能力攻击+10%，队友光环+3%：`M=1.15*1.10*1.03=1.30295`。
- 羁绊暴击威力+15%、武器能力暴击威力+10%：`crit_multiplier=1.5+.15+.10=1.75`；普通武器暴击格不在此数值里。
- 羁绊必杀威力+15%、武器能力必杀威力+5%：`S=1.15*1.05=1.2075`；0Chain+60%攻击 Buff 实际+72.45%；1stChain（无额外 BB）时+79.695%。
- 羁绊/武器的 Button Buff 仅在触发条件和激活范围满足时贡献下一发 Chain；不能自动归入必杀威力 UP。
