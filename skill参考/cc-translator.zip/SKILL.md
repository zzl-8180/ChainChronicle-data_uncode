---
name: cc-translator
description: Translate Chain Chronicle (锁链战记/チェンクロ) skill, awakening, and bond text from Japanese to Chinese for database entry. Use when the user provides Japanese text or screenshots of Chain Chronicle game content (skills, 必杀, 觉醒, 羁绊, 共鸣必杀) and requests translation into Chinese database format. Triggers on keywords like 锁链战记, Chain Chronicle, チェンクロ, 必杀翻译, 觉醒翻译, 羁绊翻译, 共鸣必杀, or requests to translate game skill text with database formatting requirements.
---

# Chain Chronicle Translation Skill

Translate Chain Chronicle Japanese skill/awakening/bond text into structured Chinese for database entry.

## Glossary (Built-in)

The term glossary is embedded at `references/glossary.md` (sections: 技能 / 觉醒 / 共鸣 / 羁绊 / Extra能力). Read it before every translation task — no external XLSX is needed. Rows with an empty Japanese column are a Chinese phrasing/numbering library: use them as style and format references when composing sentences.

## Workflow Overview

1. Receive Japanese source (text or image)
2. If image: read the image directly to extract Japanese text
3. Read `references/glossary.md`
4. Match text against glossary entries, applying term mappings
5. Preserve placeholders like (？%) and (？秒) exactly
6. Apply the fixed rules below (they override the glossary on conflict)
7. For 共鸣必杀: apply the three-section output format
8. Report any unmatched terms to the user

## Translation Steps (Standard)

1. Identify the text type (skill/awakening/bond) and select the matching glossary section
2. Search the glossary for exact or near-exact Japanese matches
3. Apply the Chinese translation from the glossary for matched terms
4. Preserve all placeholders: (？%), (？秒), (？), (？个), etc.
5. Convert Japanese punctuation to Chinese punctuation (。→。、→，)
6. Apply numeric formatting rules below
7. Flag any Japanese terms not found in the glossary

## Numeric Placeholder Rules

- **Standard**: Keep (？%) as-is for database updates
- **Time**: Always write "一定时间内" as "一定时间内（？秒）"
- **必杀效果增加**: Change ALL "？%" in the text to "？/？%"
- **效果上升 (in 觉醒)**: When a 觉醒 sentence contains 效果上升, change every "（？%）" earlier in the SAME sentence to "（？%、？%）"
- Never remove or alter placeholder symbols without explicit instruction

## Sentence Structure Rules (MUST follow)

1. **Subject-first for time-limited effects**: In any sentence with 一定时间内, put the subject (e.g. 自身, 我方全体) first, immediately followed by 一定时间内（？秒）, then the effects. Example: 自身一定时间内（？秒）攻击力（？%）增加。
2. **自身を含む<味方>** — Always translate as 我方队员（含自身）, in 共鸣, 觉醒, or anywhere else.
3. **攻击速度**: "攻击速度增加" with a limiting condition before/after it → 攻击速度增加（→1.0秒）; with no limiting condition → 攻击速度增加（→1.5秒）.
4. **觉醒 bullet merging**: In 觉醒 text, each "◆" and the line break before it becomes a Chinese semicolon "；". If the preceding sentence ends with 。or ；, remove that ending punctuation first.
5. **暴击连击 abbreviation**: Phrases like "暴击攻击时，暴击时变为？连击的范围攻击" are shortened to "暴击攻击时变为？连击的范围攻击" (keep the actual hit count).

## 共鸣必杀 (Resonance Special) Three-Section Output

When the source text starts with 共鸣必杀, output three sections. Do not use semicolons (;) anywhere in the translation. First produce the 原文 (original translation) following standard steps, then construct:

**Section 1** — Use 原文 verbatim, except:
- A debuff clause like "被攻击的敌人一定时间内（？秒）攻击力（？%）、防御力（自身ATK*？%）、移动速度降低" must use fixed values: `被攻击的敌人一定时间内（30秒）攻击力（30/32.5%）、防御力（30/32.5%）、移动速度降低。`
- An ally-buff clause like "我方全体一定时间内（？秒）攻击力（？%）、防御力（自身ATK*？%）、移动速度、暴击率、暴击威力（？%）增加" must use: `我方全体一定时间内（？秒）攻击力（60/65%）、防御力（自身ATK*3/3.25%）、移动速度、暴击率、暴击威力（30/32.5%）增加`
- If the last sentence contains 必杀效果增加 or 效果上升, change "？%" to "？/？%".

**Section 2** — This is the 超共鸣必杀 version:
- Change the opening "【共鸣必杀/连击】" to "【超共鸣必杀/连击】".
- Remove the last sentence if it contains "1st以上" or 必杀效果增加/效果上升.
- Debuff clause values: `被攻击的敌人一定时间内（30秒）攻击力（37.5%）、防御力（37.5%）、移动速度降低。`
- Ally-buff clause values: `我方全体一定时间内（30秒）攻击力（75%）、防御力（自身ATK*3.75%）、移动速度、暴击率、暴击威力（37.5%）增加`
- Append the following DIRECTLY after the last sentence, on the SAME line (no line break before it):
  > 获得一颗万象法珠。（己方使用「共鸣必杀」时积累共鸣槽，共鸣槽积累满10次后清0，下一次必杀变为消耗为0的「超共鸣必杀」）

**Section 3** — Based on 原文:
- Remove the "共鸣必杀/" prefix (keep 【连击】).
- Remove the last sentence if it contains "1st以上" or 必杀效果增加/效果上升.
- Debuff clause values: `被攻击的敌人一定时间内（30秒）攻击力（30%）、防御力（30%）、移动速度降低。`
- Ally-buff clause values: `我方全体一定时间内（30秒）攻击力（60%）增加、防御力（自身ATK*3%）增加、移动速度增加、暴击率增加、暴击威力（30%）增加`

### Reference Section Priority

For 共鸣必杀 entries, prioritize the 技能 section of the glossary for translation references.

## Other Fixed Rules (MUST follow)

1. **"ダッシュ範囲" → "冲刺范围"** — never "冲撞范围" or other variants.
2. **Title names are NOT translated** — Skill, Awakening, and Bond titles keep original Japanese (e.g. "ワガママ魔神" stays as-is).
3. **"……にダメージを与える" format** — translate as "给……伤害（？倍）". Example: "敵にダメージを与える" → "给敌人伤害（？倍）"; "8回ダメージを与える" → "给8次伤害（？倍）".
4. **弾き飛ばし** — translate as 弹飞; when the preceding clause also inflicts status ailments and the two are connected, add the conjunction: 并弹飞.
5. **超共鸣必杀 standalone buff values** — In standalone 【超共鸣必杀】text (not part of a three-section output), the ally-buff clause uses: `攻击力（75%）、防御力（自身ATK*3.75%）、移动速度、暴击率、暴击威力（37.5%）增加`.

## Output Format

Present the final translation clearly. At the end, report:
- Any glossary terms used
- Any modifications made to the matched glossary entries
- Any Japanese terms not found in the glossary (ask user for confirmation before translating these)

## Key Constraints

- Do not arbitrarily translate terms not found in the glossary — always ask the user
- Do not remove placeholders like (？%) — they are reserved for future data updates
- Minor word adjustments (1-2 words) are acceptable, but do not change the phrasing style
- When 必杀效果增加 is present, ALL "？%" in the entire text become "？/？%"

## Resources

- `references/glossary.md` — Built-in Japanese-Chinese term glossary (技能/觉醒/共鸣/羁绊/Extra能力). Read before every task.
- `references/translation-rules.md` — Additional rules for placeholder handling, punctuation, and special formatting. If it conflicts with this SKILL.md, SKILL.md wins.
- `references/resonance-examples.md` — Input/output examples for 共鸣必杀 format. Note: its section-2 line-break and value conventions are superseded by the rules in this SKILL.md.
