# 共鸣必杀 (Resonance Special) Examples

## Example 1: Basic Resonance Special

### Input (Japanese)
共鸣必杀/敵全体に？%の闇ダメージを与える。さらに1st以上で必殺威力が？%上昇。

### 原文 (Standard Translation)
共鸣必杀/给予敌方全体？%的暗属性伤害。并且如果1st以上必杀威力上升（？%）。

### Three-Section Output

**第一段：**
共鸣必杀/给予敌方全体？%的暗属性伤害。并且如果1st以上必杀威力上升（？/？%）。

**第二段：**
共鸣必杀/给予敌方全体？%的暗属性伤害。
获得一颗万象法珠。（己方使用「共鸣必杀」时积累共鸣槽，共鸣槽积累满10次后清0，下一次必杀变为消耗为0的「超共鸣必杀」）

**第三段：**
给予敌方全体？%的暗属性伤害。

---

## Example 2: Resonance Special with Buff

### Input (Japanese)
共鸣必杀/味方全体の攻撃力を？%アップ、防御力を？%アップ。一定時間内に自身の必殺威力が？%上昇。

### 原文 (Standard Translation)
共鸣必杀/我方全体攻击力上升（？%）、防御力上升（？%）。一定时间内（？秒）自身必杀威力上升（？%）。

### Three-Section Output

**第一段：**
共鸣必杀/我方全体攻击力上升（？%）、防御力上升（？%）。一定时间内（？秒）自身必杀威力上升（？/？%）。

**第二段：**
共鸣必杀/我方全体攻击力上升（？%）、防御力上升（？%）。一定时间内（？秒）自身必杀威力上升（？%）。
获得一颗万象法珠。（己方使用「共鸣必杀」时积累共鸣槽，共鸣槽积累满10次后清0，下一次必杀变为消耗为0的「超共鸣必杀」）

**第三段：**
我方全体攻击力上升（？%）、防御力上升（？%）。一定时间内（？秒）自身必杀威力上升（？%）。

---

## Example 3: Resonance Special with 效果上升

### Input (Japanese)
共鸣必杀/敵単体に？%の雷ダメージ。味方全体の攻撃力を？%アップし、効果がアップ。

### 原文 (Standard Translation)
共鸣必杀/给予敌方单体？%的雷属性伤害。我方全体攻击力上升（？%、？%）。

### Three-Section Output

**第一段：**
共鸣必杀/给予敌方单体？%的雷属性伤害。我方全体攻击力上升（？%、？%）。

**第二段：**
共鸣必杀/给予敌方单体？%的雷属性伤害。
获得一颗万象法珠。（己方使用「共鸣必杀」时积累共鸣槽，共鸣槽积累满10次后清0，下一次必杀变为消耗为0的「超共鸣必杀」）

**第三段：**
给予敌方单体？%的雷属性伤害。

---

## Processing Summary Table

| Step | Action | Scope |
|------|--------|-------|
| 1 | Produce 原文 using standard translation rules | Entire text |
| 2 | Section 1: 原文 + ？%→？/？% if 必杀效果增加 present | Full text |
| 3 | Section 2: Remove last sentence (1st/必杀效果增加) + append 万象法珠 | From 原文 |
| 4 | Section 3: Remove "共鸣必杀/" prefix + remove last sentence | From 原文 |

## Critical Rules

- The 万象法珠 text must be appended **exactly** as stated, no modifications
- Never use semicolons (;) in any section of the output
- Placeholder rules (？%→？/？% etc.) apply per-section based on section content
- When removing the last sentence in Section 2/3, remove the entire sentence including its punctuation
