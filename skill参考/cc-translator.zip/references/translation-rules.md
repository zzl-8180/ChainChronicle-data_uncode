# Translation Rules Reference

## Term Matching Strategy

When searching the XLSX template:

1. **Exact match**: Japanese text in template matches input exactly → use Chinese translation directly
2. **Partial match**: Input contains the template text plus additional segments → use template translation for matched part, flag the extra segments
3. **Fuzzy match**: Input is similar but not identical → use closest template entry and note the differences
4. **No match**: Flag the Japanese term and ask user for translation

## Punctuation Mapping

Map Japanese punctuation to Chinese equivalents strictly:

| Japanese | Chinese | Notes |
|----------|---------|-------|
| 。 | 。 | Full-width period stays |
| 、 | ， | Ideographic comma to full-width comma |
| 「 | 「 | Keep Japanese corner brackets |
| 」 | 」 | Keep Japanese corner brackets |
| （ | （ | Full-width parentheses |
| ） | ） | Full-width parentheses |
| ・ | ・ | Middle dot stays |
| ！ | ！ | Exclamation stays |
| ？ | ？ | Question mark stays |

## Placeholder Preservation Rules

Placeholders are marked with ？ and are critical for database entry. Never remove or modify them.

### Standard Placeholders

- `(？%)` — Percentage value (skill power, buff rate, etc.)
- `(？秒)` — Duration in seconds
- `(？)` — Generic numeric value
- `(？个)` — Item/count quantity

### Time Duration Rule

Any "一定时间内" must include the seconds placeholder:
- Input: 一定时间内攻撃力が？%上昇
- Output: 一定时间内（？秒）攻击力上升（？%）

### 必杀效果增加 Rule

When the text contains "必杀效果增加" or similar wording at the end:
- Find ALL "？%" occurrences in the **entire** text
- Change each to "？/？%"
- Example: 攻击力上升（？%）、防御力上升（？%）→ 攻击力上升（？/？%）、防御力上升（？/？%）

### 效果上升 Rule

When the text contains "效果上升" or similar wording:
- Find "？%" in the clause immediately preceding 效果上升
- Change to "？%、？%"
- Only affects the nearest preceding clause, not the entire text

## Text Modification Boundaries

Allowed: minor additions/deletions of 1-2 words for naturalness

Not allowed:
- Changing the phrasing style (e.g., "攻击力上升" cannot become "提升攻击力")
- Removing placeholder markers
- Adding unstated effects
- Reordering clauses

## Unmatched Terms Handling

When a Japanese term has no match in the template:

1. Keep the Japanese term as-is in the output
2. Mark it with 【待确认: 日文原文】
3. List all unmatched terms at the end of output
4. Ask user to provide Chinese translations for confirmation
5. Do not guess or auto-translate

## 共鸣必杀 Special Processing

See `resonance-examples.md` for detailed input/output examples.

### Key differences from standard translation:

- No semicolons (;) allowed anywhere in output
- Three-section output format mandatory
- Section 2 always appends the 万象法珠 text exactly
- Section 3 always removes "共鸣必杀/" prefix
- Placeholder rules from standard translation still apply to each section
